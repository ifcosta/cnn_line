#!/usr/bin/env python
import os, sys
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # or any {'0', '1', '2', '3'}
sys.path.append('igor_workspace/src/cnn_line/src')

import rospy, cv2, math, tf2_ros, tf_conversions, datetime, gc
import numpy as np

import tensorflow as tf
from keras.models import Model

from cv_bridge import CvBridge
from image_geometry.cameramodels import PinholeCameraModel
from sensor_msgs.msg import CameraInfo, CompressedImage
from std_msgs.msg import String
from geometry_msgs.msg import Twist, PoseStamped, Pose2D
from gazebo_msgs.srv import GetPhysicsProperties, SetPhysicsProperties, SetModelState
from gazebo_msgs.msg import ModelState
from cnn_line.srv import UpdateService, UpdateServiceRequest


from math import sin, cos
from time import time_ns, sleep

from state_estimation.udacity import *
from suppress_TF_REPEATED_DATA import *
from deep_learning.models import DeeplabV3Plus,LineModel,DeeplabV3_mobile2,DeeplabV3_mobile2_v2, LineModel_mobile2
from segmentation.exg import *

import rospy

#DeepLab Network Inference
COLORMAP = np.asarray([[255,0,0],[0,0,255],[0,255,0],[255,0,255]])
x0_true, x1_true, theta_true = 0,0,0

def decode_segmentation_masks2(mask, colormap, n_classes):
    shape = (IMAGE_SIZE,IMAGE_SIZE)
    r = np.empty(shape,dtype=np.uint8)
    g = np.empty(shape,dtype=np.uint8)
    b = np.empty(shape,dtype=np.uint8)
        
    for l in range(0, n_classes):
        idx = mask == l
        r[idx] = colormap[l, 0]
        g[idx] = colormap[l, 1]
        b[idx] = colormap[l, 2]
        
    rgb = np.stack([r, g, b], axis=2)
    return rgb

def decode_segmentation_masks(mask, colormap, n_classes):
    shape = (IMAGE_SIZE, IMAGE_SIZE)
    indices = np.arange(shape[0] * shape[1]).reshape(shape)
    rgb = colormap[mask.ravel()].reshape(shape + (3,))
    return np.uint8(rgb)

def predict(image):
    soft_mask,x0,x1 = model.predict(np.expand_dims((image), axis=0))
    soft_mask = np.squeeze(soft_mask)
    x0 = np.squeeze(x0)
    x1 = np.squeeze(x1)

    prediction_colormap = decode_segmentation_masks(np.argmax(soft_mask, axis=2), COLORMAP, NUM_CLASSES) #2.5ms
        
    return prediction_colormap, soft_mask, x0, x1

def predict_line(image):
    x0,x1 = model.predict(np.expand_dims((image), axis=0))
    x0 = np.squeeze(x0)
    x1 = np.squeeze(x1)
    return x0, x1

#ROS
def topimg_callback(msg):
    global cv_image_top
    np_arr = np.frombuffer(msg.data, np.uint8)
    cv_image_top = cv2.cvtColor(cv2.imdecode(np_arr, cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)

def botimg_callback(msg):
    global cv_image_bot
    np_arr = np.frombuffer(msg.data, np.uint8)
    cv_image_bot = cv2.cvtColor(cv2.imdecode(np_arr, cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)

def pose_callback(msg):
    global robot_pose
    robot_pose = msg

def line_callback(msg):
    global x0_true, x1_true, theta_true
    x0_true = msg.x
    x1_true = msg.y
    theta_true = msg.theta

def update_line(line):
    rospy.wait_for_service('/update_true_line')
    try:
        service_proxy = rospy.ServiceProxy('/update_true_line', UpdateService)
        
        request = UpdateServiceRequest()
        request.code = float(line)
        
        response = service_proxy(request)
        
        #print(datetime.datetime.now(), response)
    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

def call_spawner(action):
    rospy.wait_for_service('/spawn_field')
    try:
        service_proxy = rospy.ServiceProxy('/spawn_field', UpdateService)
        
        request = UpdateServiceRequest()
        request.code = float(action) #valid actions: 0, 1,2,3 ,10
        
        response = service_proxy(request)
        
        print(datetime.datetime.now(), response)
    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

def get_caminfo():
    global camera
    cam_info = None
    cam_info = rospy.wait_for_message('/nav_front/camera_info',CameraInfo)
    if cam_info is not None:
        camera = PinholeCameraModel()
        camera.fromCameraInfo(cam_info)

def update_sim_speed(new_time_step,new_update_rate):
    rospy.wait_for_service('gazebo/get_physics_properties')
    rospy.wait_for_service('gazebo/set_physics_properties')

    try:
        get_physics_properties = rospy.ServiceProxy('gazebo/get_physics_properties', GetPhysicsProperties)
        props = get_physics_properties()
    except rospy.ServiceException as e:
        rospy.logerr('couldn\'t get physics properties while preparing '
                    'to set physics properties: ' + str(e))

    time_step = new_time_step
    max_update_rate = float(new_update_rate)
    gravity = props.gravity

    try:
        set_physics_properties = rospy.ServiceProxy('gazebo/set_physics_properties', SetPhysicsProperties)
        set_physics_properties(time_step       = time_step,
                            max_update_rate = max_update_rate,
                            gravity         = gravity,
                            ode_config      = props.ode_config)
        #print('new',time_step,max_update_rate)
    except rospy.ServiceException as e:
        rospy.logerr('couldn\'t set physics properties: ' + str(e))

def gazebo_set_pos(modelname,pose):
    rospy.wait_for_service('/gazebo/set_model_state')

    (x,y,z,w) = tf_conversions.transformations.quaternion_from_euler(0,0,pose[2])

    state_msg = ModelState()
    state_msg.model_name = modelname
    state_msg.pose.position.x = pose[0]
    state_msg.pose.position.y = pose[1]
    state_msg.pose.position.z = 0.035
    state_msg.pose.orientation.x = x
    state_msg.pose.orientation.y = y
    state_msg.pose.orientation.z = z
    state_msg.pose.orientation.w = w

    rospy.wait_for_service('/gazebo/set_model_state')
    try:
        set_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
        resp = set_state( state_msg )

    except rospy.ServiceException as e:
        print ("Service call failed: %s" %e)

def lin_denormalize(x0,x1,img_size):
    if x0<0.001:
        x0 = -640
    elif x0>0.999:
        x0 = 1280
    else:
        x0 = int(np.round((-img_size/2.782609)*np.log((1 - x0) / x0) + img_size/2))
    
    if x1<0.001:
        x1 = -640
    elif x1>0.999:
        x1 = 1280
    else:
        x1 = int(np.round((-img_size/2.782609)*np.log((1 - x1) / x1) + img_size/2))

    #if x0 < 0.1:
    #    x0 = round((x0*img_size*10)-img_size)
    #elif x0 > 0.9:
    #    x0 = round(((x0-0.9)*img_size*10)+img_size)
    #else:
    #    x0 = round(((x0-0.1))*img_size*1.25)
    
    #if x1 < 0.1:
    #    x1 = round((x1*img_size*10)-img_size)
    #elif x1 > 0.9:
    #    x1 = round(((x1-0.9)*img_size*10)+img_size)
    #else:
    #    x1 = round(((x1-0.1))*img_size*1.25)
    
    return x0, x1

class controle():
    def __init__(self):

        self.image_size = 640
        self.camera_mode = 'top'
        self.offset = 0
        self.line_num = 0

        self.fps = 0
        self.fps_sim = 0
        self.proc_time_arr = np.zeros(10)
        self.view_time_arr = np.zeros(10)
        self.ctrl_time_arr = np.zeros(10)

        self.time_process = 0
        self.time_view = 0
        self.time_control = 0
        self.count = 0
        self.key = -1

        self.w = 0
        self.speed = 0
        self.robot_X = 0
        self.robot_Y = 0
        self.robot_yaw = 0
        self.img_top = None
        self.img_bot = None
        self.line_dir = 'north'
        self.status = 'start'

        self.wait_start = 0
        self.waiting = False
        self.img_top_stack = []
        self.img_bot_stack = []

        self.ang = 0
        
        self.vel = Twist()

        self.row_pos = 1.0 + self.offset

        self.auto = True
        
        self.out_file = None

    def view(self,image=None):
        if image is None:
            if self.camera_mode == 'top':
                image = cv2.cvtColor(cv_image_top, cv2.COLOR_RGB2BGR)
            elif self.camera_mode == 'bot':
                image = cv2.cvtColor(cv_image_bot, cv2.COLOR_RGB2BGR)
            else:
                self.key = cv2.waitKey(1)
                return
        
        self.proc_time_arr [self.count] = self.time_process*1000
        self.view_time_arr [self.count] = self.time_view*1000
        self.ctrl_time_arr [self.count] = self.time_control*1000
        
        if self.count == 9: self.count = 0
        else: self.count +=1
        
        cv2.putText(image,f'FPS: {self.fps} (SIM: {self.fps_sim}) Auto:{str(self.auto)}', (1, 10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(image,f'Spd: {float(self.vel.linear.x):0.3}L {float(self.vel.angular.z):0.3}A ',(1, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(image,f'infr: {np.average(self.proc_time_arr):0.3}ms', (540, 10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(image,f'view:  {np.average(self.view_time_arr):0.3}ms', (535, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(image,f'ctrl: {np.average(self.ctrl_time_arr):0.3}ms', (540, 46), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.imshow('Camera View - Q: Quit', image)
        self.key = cv2.waitKey(1)

    def interface(self):
        if self.key == -1:
            pass
        elif self.key == 119: #w
            self.speed += 0.2
        elif self.key == 115: #s
            self.speed -= 0.2
        elif self.key == 101: #e
            self.auto = not self.auto
            self.speed = 0
        elif self.key == 97: #a
            self.ang += 0.1
        elif self.key == 100: #d
            self.ang -= 0.1
        elif self.key == 113:
            return 'quit'
        return 'ok'

    def get_robot_pos(self):
        self.robot_X = robot_pose.pose.position.x
        self.robot_Y = robot_pose.pose.position.y

        _,_,yaw = tf_conversions.transformations.euler_from_quaternion([
                    robot_pose.pose.orientation.x,robot_pose.pose.orientation.y,
                    robot_pose.pose.orientation.z,robot_pose.pose.orientation.w])
        self.yaw = yaw

        if 1.65 < yaw or yaw < -1.65:
            self.robot_yaw = np.abs(np.abs(yaw)-np.pi)
            self.line_dir = 'south'
            self.robot_X = np.abs(robot_pose.pose.position.x - 8.5)
            self.robot_Y = -(robot_pose.pose.position.y - self.row_pos)
        else:
            self.robot_yaw = np.abs(yaw)
            self.line_dir = 'north'
            self.robot_X = robot_pose.pose.position.x + 0.5
            self.robot_Y = robot_pose.pose.position.y - self.row_pos

        self.img_top = cv_image_top
        self.img_bot = cv_image_bot

    def fit_line(self,x_point,y_point,predict_list):
        coef = np.polyfit(y_point,x_point,deg=1)

        x = []
        for value in predict_list:
            x.append(int(np.round(coef[0]*value + coef[1])))

        x0 = coef[0]*y_point[0] + coef[1]
        x1 = coef[0]*y_point[1] + coef[1]
        if self.camera_mode == 'top':
            theta = math.atan2(480,(x1-x0)) - np.pi/2
        elif self.camera_mode == 'bot':
            theta = - math.atan2(480,(x1-x0)) + np.pi/8 + 0.080

        return x,predict_list,theta

    def actuate(self,X,theta):
        #print(X, math.degrees(theta))
        if self.camera_mode == 'top':
            W = np.squeeze(self.rowController(X, theta, lambdax = 0.6, lambdatheta = 1, Vconst = 0.6, Wmax = 0.5, ro = 0.707, tz = 0.95, ty = 0.16))
        elif self.camera_mode == 'bot':
            W = np.squeeze(self.rowController(X, theta, lambdax = 0.4, lambdatheta = 0.6, Vconst = 0.6, Wmax = 0.5, ro = 0.707, tz = 0.95, ty = 0.16))
        return W
    
    #Controller
    def rowController(self, point_x, theta, lambdax = 0.5, lambdatheta = 0.5, Vconst = 0.5, Wmax = 0.5, ro = 0.707, tz = 0.95, ty = 0.16):
        """point_x must be normalized wtr the width of the image (point_x E [-1, 1])"""

        Y = -1
        X = point_x

        Lx = np.array([(-sin(ro) - Y * cos(ro))/tz, 0, (X * (sin(ro)+Y*cos(ro)))/tz, X*Y, -1-X**2, Y])
                        
        Ltheta = np.array([(cos(ro) * cos(theta)**2)/tz, 
                        (cos(ro) * cos(theta) * sin(theta))/tz, 
                        -(cos(ro)*cos(theta) * (Y*sin(theta) + X * cos(theta)))/tz, 
                        -(Y*sin(theta) + X*cos(theta)) *cos(theta), 
                        -(Y*sin(theta) + X*cos(theta))*sin(theta), 
                        -1])

        Ls = np.vstack((Lx, Ltheta))

        Tv = np.array([ 0, -sin(ro),  cos(ro), 0, 0, 0 ]).transpose()[:, None]
        Tw = np.array([-ty, 0, 0, 0, -cos(ro), -sin(ro)]).transpose()[:, None]

        Ar = np.matmul(Ls, Tv)
        Br = np.matmul(Ls, Tw)

        Brp = np.linalg.pinv(Br)

        ex = point_x
        etheta = theta

        matriz_ganho_erro = np.array([lambdax * ex, lambdatheta * etheta]).transpose()[:,None]

        w = - np.matmul(Brp,(matriz_ganho_erro + Ar * Vconst))
        if(abs(w) > Wmax):
            w = Wmax * np.sign(w)

        return w 

    def inference(self):
        global x0_true, x1_true
        proc_start = rospy.get_time()

        if self.camera_mode == 'top':
            if len(self.img_top_stack) < 2: 
                self.img_top_stack = [self.img_top.copy() for _ in range(7)]

            self.img_top_stack.append(self.img_top)
            self.img_top_stack.pop(0)
            img = self.img_top_stack[6]
        
        else:
            if len(self.img_bot_stack) < 2: 
                self.img_bot_stack = [self.img_bot.copy() for _ in range(7)]

            self.img_bot_stack.append(self.img_bot)
            self.img_bot_stack.pop(0)
            img = self.img_bot_stack[6]
            
        start = time_ns()
        if self.mode == 'pred':
            self.output_A = cv2.resize(img,dsize=(self.image_size, self.image_size))

            self.output_B, soft_pred, self.x0_pred, self.x1_pred = predict((self.output_A/127.5) -1)

            self.x0_pred, self.x1_pred = lin_denormalize(self.x0_pred, self.x1_pred,img.shape[1])

            y0,y1 = 0,480

        elif self.mode == 'line':
            self.output_A = cv2.resize(img,dsize=(self.image_size, self.image_size))

            self.x0_pred, self.x1_pred = predict_line((self.output_A/127.5) -1)

            self.x0_pred, self.x1_pred = lin_denormalize(self.x0_pred, self.x1_pred,img.shape[1])

            y0,y1 = 0,480

        elif self.mode == 'true':
            self.output_A = cv2.line(cv2.cvtColor(img, cv2.COLOR_RGB2BGR) ,(int(x0_true),int(0)),(int(x1_true),int(480)),(255,255,255),3)
            self.x0_pred = x0_true
            self.x1_pred = x1_true
            y0,y1 = 0,480

        elif self.mode == 'box':
            mask = exg_th(self.img_top_stack[6])
            self.output_A, self.output_B, X, X2 = udacity_pipeline(img,mask,order=1)
            self.x1_pred = X *img.shape[1]+img.shape[1]/2
            self.x0_pred = X2*img.shape[1]+img.shape[1]/2
            y0,y1 = 240,480
        
        x_predic,_,self.theta = self.fit_line([self.x0_pred,self.x1_pred],[y0,y1],[0,420,480])
        self.x0_pred = x_predic[0]
        self.xh_pred = x_predic[1]
        self.x1_pred = x_predic[2]

        if self.camera_mode == 'top':
            X = (x_predic[0]/(img.shape[1]/2))-1
            W = self.actuate(X,self.theta)
        else:
            x_predic,_,theta_corr = self.fit_line([self.xh_pred,self.x1_pred],[0,480],[0])
            X = (x_predic[0]/(img.shape[1]/2))-1
            W = self.actuate(X,theta_corr)

        end = time_ns()
        self.real_inf_time = np.round((end-start)/1000000,1)
        proc_end = rospy.get_time()
        self.time_process = proc_end-proc_start
        return np.squeeze(W)

    def visualize(self):
        global x0_true, x1_true
        view_start = rospy.get_time()
        img = self.img_top
        if self.mode == 'pred':
            pred_comp = cv2.addWeighted(cv2.cvtColor(self.output_A, cv2.COLOR_RGB2BGR), 0.7, cv2.cvtColor(self.output_B, cv2.COLOR_RGB2BGR), 0.3, 10)
            pred_comp = cv2.resize(pred_comp, (img.shape[1],img.shape[0]), interpolation = cv2.INTER_NEAREST)
            pred_comp = cv2.line(pred_comp ,(int(x0_true),int(0)),(int(x1_true),int(480)),(255,255,255),3)

        elif self.mode == 'line':
            pred_comp = cv2.resize(cv2.cvtColor(self.output_A, cv2.COLOR_RGB2BGR), (img.shape[1],img.shape[0]), interpolation = cv2.INTER_NEAREST)
            pred_comp = cv2.line(pred_comp ,(int(x0_true),int(0)),(int(x1_true),int(480)),(255,255,255),3)

        elif self.mode == 'true':
            pred_comp = self.output_A

        elif self.mode == 'box':
            self.output_A = adjustPerspective(cv2.cvtColor(self.output_A, cv2.COLOR_RGB2BGR))
            pred_comp = cv2.addWeighted(self.output_A, 1, self.output_B, 0.5, 0)
            pred_comp = cv2.line(pred_comp ,(int(x0_true),int(0)),(int(x1_true),int(480)),(255,255,255),3)

        pred_comp = cv2.line(pred_comp,(self.x0_pred, 0), (self.x1_pred, img.shape[0]), (0,   0,   0),6)
        pred_comp = cv2.line(pred_comp,(self.x0_pred, 0), (self.x1_pred, img.shape[0]), (0, 255, 255),2)

        self.view(pred_comp)
        view_end = rospy.get_time()
        self.time_view = view_end-view_start

    def man_south(self):
        while True:
            if robot_pose.pose.position.x > -0.5:
                self.vel.angular.z = 0.0
                self.vel.linear.x = 0.3
            else:
                self.vel.angular.z = 0.4
                self.vel.linear.x = 0.11
            self.get_robot_pos()
            if -0.25 < self.yaw and self.yaw < 0.25:
                self.vel.angular.z = 0
                self.vel.linear.x = 0
                pub.publish(self.vel)
                break
            pub.publish(self.vel)

    def man_north(self):
        while True:
            if robot_pose.pose.position.x < 10.5:
                self.vel.angular.z = 0.0
                self.vel.linear.x = 0.3
            else:
                self.vel.angular.z = -0.4
                self.vel.linear.x = 0.0
            self.get_robot_pos()
            if 2.8 < self.yaw or self.yaw < -2.8:
                self.vel.angular.z = 0
                self.vel.linear.x = 0
                pub.publish(self.vel)
                break
            pub.publish(self.vel)

    def maneuver (self):
        self.vel.angular.z = 0
        self.vel.linear.x = 0
        pub.publish(self.vel)
        self.view()

        erro = np.random.choice([0.12,-0.12])
        if self.line_dir == 'north':
            self.speed = 0
            update_line(self.row_pos)
            gazebo_set_pos('soybot',(8.5, self.row_pos + erro, np.pi + erro-0.03))
            #self.man_north()
            self.line_dir = 'south'

        elif self.line_dir == 'south':
            self.row_pos -= 0.5
            if self.row_pos == (-1.5 + self.offset):
                self.restart()
                return 1
            self.speed = 0
            update_line(self.row_pos)
            gazebo_set_pos('soybot',(-0.5, self.row_pos + erro, 0 - erro-0.03))
            #self.man_south()
            self.line_dir = 'north'

        sleep(1)
        self.open_file()
        rate.sleep()
        return 0
    
    def open_file(self):
        if self.out_file is not None:
            self.out_file.close()
        self.line_num += 1
        name = str(self.image_size)+'_'+self.camera_mode+'_'+backbone+'_'+net_name[-12:-5]
        self.out_file = open(log_directory+'/'+world+'/'+name+'/'+str(self.line_num)+'_'+name+'.txt', 'w')
        print('robot_x,robot_y,robot_yaw,x0_true,x1_true,theta_true,x0_pred,x1_pred,theta,inf_time,flag', file=self.out_file)

    def restart(self):
        self.vel.angular.z = 0
        self.vel.linear.x = 0
        pub.publish(self.vel)

        if self.row_pos != (-1.5 + self.offset):
            self.open_file()

        self.row_pos = 1.0 + self.offset

        erro = np.random.choice([0.12,-0.12])

        update_line(self.row_pos)
        gazebo_set_pos('soybot',(-0.5, self.row_pos + erro, 0 - erro-0.03))
        self.line_dir = 'north'
        self.status = 'start'
        sleep(2)
        rate.sleep()
    
    #Main Controller
    def run(self,mode):
        global x0_true, x1_true, theta_true
        self.mode = mode
        self.restart()
        rate.sleep()
        erro = 0
        ret = 0
        self.get_robot_pos()
        while not rospy.is_shutdown():
            start = time_ns()
            start_sim = rospy.get_time()
            control_start = rospy.get_time()

            if self.auto:
                if self.status == 'inrow':
                    #Fail safe Lateral
                    if (self.robot_Y < (- 0.25)) or (self.robot_Y > (+ 0.25)):
                        self.status = 'lost'

                    #End row check
                    if self.robot_X > 7.5:
                        self.status = 'end'

                elif self.status == 'start':
                    #Enter inrow mode after 0.5m
                    self.wait_start = rospy.get_time()
                    if self.robot_X > 0.25:
                        self.status = 'inrow'

                elif self.status == 'end':
                    #Teleports to the next lane if End row reached
                    ret = self.maneuver()
                    rate.sleep()
                    self.status = 'start'

                elif self.status == 'lost':
                    if self.waiting == False:
                        self.waiting = True

                    elif (rospy.get_time() - self.wait_start) > 5 or self.robot_X > 25:
                        #Teleports to the next lane if lost
                        ret = self.maneuver()
                        rate.sleep()
                        self.status = 'start'
                        self.waiting = False

                if ret == 1:
                    #ret=1 : Last row completed, stopping controller
                    rate.sleep()
                    rate.sleep()
                    break
                #print(self.status)

                #Speed Up
                self.speed = 0.4

            self.get_robot_pos()
            if cv_image_top is not None and cv_image_bot is not None:
                self.w = self.inference()

                erro = (1-0.25)*erro + np.random.normal(0,0.02) #erro Brownian Motion
                self.vel.angular.z = self.w * 1.2 * self.auto + self.ang# + erro
                self.vel.linear.x = self.speed
                #self.vel.linear.x = 0
                pub.publish(self.vel)

                self.visualize()

                if self.interface() == 'quit':
                    #Q key breaks execution
                    break

            #LOG movment 
            if self.auto:
                xl  = int(np.round(self.robot_X*1000))
                yl  = int(np.round(self.robot_Y*1000))
                zr  = np.round(math.degrees(self.robot_yaw),2)
                x0t = x0_true
                x1t = x1_true
                tht = np.round(math.degrees(theta_true),2)
                x0p = self.x0_pred
                x1p = self.x1_pred
                thp = np.round(math.degrees(self.theta),2)
                print(f'{xl},{yl},{zr},{x0t},{x1t},{tht},{x0p},{x1p},{thp},{self.real_inf_time},{self.status}',file=self.out_file)
                #print(f'{xl},{yl},{zr},{x0t},{x1t},{tht},{x0p},{x1p},{thp},{self.real_inf_time},{self.status},{rospy.get_time() - self.wait_start}')

            control_end = rospy.get_time()
            self.time_control = control_end-control_start

            rate.sleep()

            end = time_ns()
            end_sim = rospy.get_time()
            self.fps_sim = np.round(1/(end_sim-start_sim),1)
            self.fps = np.round((1/((end-start)/1000000000)),1)

        self.vel.angular.z = 0
        self.vel.linear.x = 0
        pub.publish(self.vel)

if __name__ == '__main__':
    #tf.keras.utils.disable_interactive_logging()
    
    tf.compat.v1.disable_eager_execution()
    rospy.init_node('basic_controller')

    pub_cmd = rospy.Publisher('/field_spawner', String, queue_size=10)

    #get_caminfo()

    bridge = CvBridge()
    robot_pose = PoseStamped()
    message = String()
    robot_pose.header.frame_id = "world"
    model_ = "soybot"
    model_idx = 0
    camera = None
    
    pub = rospy.Publisher('/soybot/cmd_vel', Twist, queue_size=10)
    rospy.Subscriber('/soybot/camera/center/image_raw/compressed' , CompressedImage , topimg_callback)
    rospy.Subscriber('/soybot/camera/rear/image_raw/compressed', CompressedImage , botimg_callback)
    rospy.Subscriber('/soybot_pose', PoseStamped , pose_callback)
    rospy.Subscriber('/true_line', Pose2D , line_callback)
    #supress = suppress_TF_REPEATED_DATA()

    mytfBuffer = tf2_ros.Buffer()
    listener = tf2_ros.TransformListener(mytfBuffer)
    rate = rospy.Rate(10)

    rospy.sleep(1)

    call_spawner(10.0)

    worldlist = ['field1','field3','field5']
    #worldlist = ['testes','testes2','testes3']
    wid = [1,3,5]
    for jj in range(len(worldlist)):
        world = worldlist[jj]

        rospy.sleep(1)
        call_spawner(wid[jj])

        redes = ['none','none','none',
                 'mixedtop256/256px_top_res_aux_true_400ep_topcam0ft.hdf5',
                 'mixedtop256/256px_top_mob_aux_true_400ep_topcam0ft.hdf5',
                 'mixedtop256/256px_top_res_aux_false_400ep_topcam0ft.hdf5',
                 'mixedtop256/256px_top_mob_aux_false_400ep_topcam0ft.hdf5',
                 'mixedtop256/256px_bot_res_aux_true_400ep_botcam0ft.hdf5',
                 'mixedtop256/256px_bot_mob_aux_true_400ep_botcam0ft.hdf5',
                 'mixedtop256/256px_bot_res_aux_false_400ep_botcam0ft.hdf5',
                 'mixedtop256/256px_bot_mob_aux_false_400ep_botcam0ft.hdf5',
                 'mixedtop256/512px_top_res_aux_true_400ep_topcam0ft.hdf5',
                 'mixedtop256/512px_top_mob_aux_true_400ep_topcam0ft.hdf5',
                 'mixedtop256/512px_top_res_aux_false_400ep_topcam0ft.hdf5',
                 'mixedtop256/512px_top_mob_aux_false_400ep_topcam0ft.hdf5',
                 'mixedtop256/512px_bot_res_aux_true_400ep_botcam0ft.hdf5',
                 'mixedtop256/512px_bot_mob_aux_true_400ep_botcam0ft.hdf5',
                 'mixedtop256/512px_bot_res_aux_false_400ep_botcam0ft.hdf5',
                 'mixedtop256/512px_bot_mob_aux_false_400ep_botcam0ft.hdf5']
        redes = ['sigmoid2/256px_bot_res_aux_false_300ep_1field9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_3field9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_5field9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_simmix9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_simtop9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_simbot9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_soybot9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_1field9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_3field9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_5field9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_simmix9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_simtop9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_simbot9.hdf5',
                 'sigmoid2/256px_bot_res_aux_false_300ep_soybot9.hdf5',
                 'none','none','none']
        
        op_mods       = ['line'  ,'line'  ,'line'  ,'line'  ,
                         'line'  ,'line'  ,'line'  ,'line'  ,
                         'line'  ,'line'  ,'line'  ,'line'  ,
                         'line'  ,'line'  ,
                         'true'  ,'true'  ,'box'   ]
                         
        image_sizes   = [ 256    , 256    , 256    , 256    ,
                          256    , 256    , 256    , 256    ,
                          256    , 256    , 256    , 256    ,
                          256    , 256    ,
                          640    , 640    , 640    ]
                          
        camera_places = ['top'   ,'top'   ,'top'   ,'top'   ,
                         'top'   ,'top'   ,'top'   ,'bot'   ,
                         'bot'   ,'bot'   ,'bot'   ,'bot'   ,
                         'bot'   ,'bot'   ,
                         'top'   ,'bot'   ,'top'   ]
                         
        backbones     = ['line_resn','line_resn','line_resn','line_resn',
                         'line_resn','line_resn','line_resn','line_resn',
                         'line_resn','line_resn','line_resn','line_resn',
                         'line_resn','line_resn',
                         'tf2'      ,'tf2'      ,'udacty'   ,]
                         
        sim_speeds    = [ 500    , 500    , 500    , 500    , 500    , 500    , 500    , 500    , 500    , 500    ,
                          500    , 500    , 500    , 500    , 500    , 500    , 500    , 500    , 500    , 500    , 500    ]

        try:
            for i in range(len(redes)):
                i+=0
                IMAGE_SIZE = image_sizes[i]
                camera_place = camera_places[i]
                op_mod = op_mods[i]
                backbone = backbones[i]
                sim_speed = 1000
                model = None

                rospy.set_param('/camera_placement', camera_place)

                if camera_place == 'bot': NUM_CLASSES = 4
                else: NUM_CLASSES = 4

                if backbone.find('line')<0:
                    aux = "res_aux_true"
                    if backbone.find("mobile")>0:
                        aux = "mob_aux_true"
                else:
                    aux = "res_aux_false"
                    if backbone.find("mobile")<0:
                        aux = "mob_aux_false"

                net_name = redes[i]
                
                update_sim_speed(0.001, sim_speed)
                log_directory = 'MLOG_sigmoid9'
                try:
                    os.mkdir(log_directory)
                except:
                    pass

                try:
                    os.mkdir(log_directory+'/'+world)
                except:
                    pass

                try:
                    os.mkdir(log_directory+'/'+world+'/'+str(IMAGE_SIZE)+'_'+camera_place+'_'+backbone+'_'+net_name[-12:-5])
                except:
                    pass

                print(datetime.datetime.now(),'Loading Model', net_name)

                if   backbone == 'resnet_v0':
                    print(datetime.datetime.now(),backbone)
                    model = DeeplabV3Plus(image_size = IMAGE_SIZE, num_classes = NUM_CLASSES)
                    model.load_weights(os.path.dirname(__file__)+'/'+'net_weights'+'/' + net_name)
                    print(datetime.datetime.now(),'resnet model loaded')
                    
                elif backbone == 'mobile_v1':
                    print(datetime.datetime.now(),backbone)
                    model = DeeplabV3_mobile2(image_size = IMAGE_SIZE, num_classes = NUM_CLASSES) #(Thesis and BRACIS compatibility)
                    model.load_weights(os.path.dirname(__file__)+'/'+'net_weights'+'/' + net_name)
                    print(datetime.datetime.now(),'mobile model loaded')
                
                elif backbone == 'mobile_v2':
                    print(datetime.datetime.now(),backbone)
                    model = DeeplabV3_mobile2_v2(image_size = IMAGE_SIZE, num_classes = NUM_CLASSES)
                    model.load_weights(os.path.dirname(__file__)+'/'+'net_weights'+'/' + net_name)
                    print(datetime.datetime.now(),'mobile model loaded')
                
                if op_mod!='pred' and model is not None:
                    print(datetime.datetime.now(),'removing aux task')
                    output_layers = [model.get_layer("x0_out").output ,model.get_layer("x1_out").output]
                    evaluate_model = Model(inputs=model.input, outputs=output_layers)
                    del model
                    gc.collect()
                    model = evaluate_model
                    print(datetime.datetime.now(),'aux task removed')

                elif backbone == 'line_resn':
                    print(datetime.datetime.now(),backbone)
                    model = LineModel(image_size=IMAGE_SIZE)
                    model.load_weights(os.path.dirname(__file__)+'/'+'net_weights'+'/' + net_name)
                    print(datetime.datetime.now(),'model resnet without aux task loaded')
                
                elif backbone == 'line_mobi':
                    print(datetime.datetime.now(),backbone)
                    model = LineModel_mobile2(image_size=IMAGE_SIZE)
                    model.load_weights(os.path.dirname(__file__)+'/'+'net_weights'+'/' + net_name)
                    print(datetime.datetime.now(),'model mobile without aux task loaded')

                my_control = controle()
                my_control.image_size = IMAGE_SIZE
                my_control.camera_mode = camera_place
                my_control.offset = 0
                my_control.line_num = 50
                
                for j in range(5):
                    rate.sleep()
                    print(datetime.datetime.now(),'run:',i,'start: ','LB3_'+backbone+'_'+op_mod+'_'+camera_place+'_'+str(IMAGE_SIZE)+'_'+world+'.txt')
                    my_control.run(op_mod)
                    rate.sleep()

                tf.keras.backend.clear_session()
            cv2.destroyAllWindows()
        
        except rospy.ROSInterruptException:
            my_control.out_file.close()
            cv2.destroyAllWindows()
            call_spawner(0)
    
    call_spawner(0)

    rospy.signal_shutdown('finished')
    
    # ssh -L localhost:8889:ugpucluster.ele.puc-rio.br:8889 ugpucluster.ele.puc-rio.br -p 22222
    # i.0531
    # ssh -L localhost:8889:wap-c61.ele.puc-rio.br:8889 wap-c61.ele.puc-rio.br -p 22222
    # [mMEl3wM
    # ssh -L localhost:8889:wap-c61.ele.puc-rio.br:8889 192.168.0.25 -p 22
    # [mMEl3wM
    # roslaunch cnn_line simulation.launch gui:=true 2> >(grep -v TF_REPEATED_DATA buffer_core) 
    # python3 train.py --image_size 256 --batch_size 32 --gpu 0 --learning_rate 0.00001 --num_epochs 300 --no_aux_task --no_mobile --folder pomar_mixed_pick --net_id pompic7
    
    # roslaunch cnn_line simulation_soybot.launch 2> >(grep -v TF_REPEATED_DATA buffer_core)