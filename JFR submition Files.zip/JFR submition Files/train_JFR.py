import argparse, sys, os, time
sys.path.append(os.path.dirname(__file__))

#python3 train.py --image_size 256 --batch_size 16 --gpu 0 --folder cam_mixed --learning_rate 0.00001 --num_epochs 20 --aux_task --no_mobile --cam_pos bot --net_id mix0

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf

from sklearn.linear_model import LinearRegression
from tensorflow import keras
from keras import layers
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, TerminateOnNaN

from pathlib import Path

parser = argparse.ArgumentParser(description="Your script description here.")

# command-line arguments
parser.add_argument("--image_size", type=int, default=256)
parser.add_argument("--batch_size", type=int, default=8)
parser.add_argument("--num_classes", type=int, default=4)
parser.add_argument("--gpu", type=str, default="0")
parser.add_argument("--folder", type=str, default="cam_mixed")

parser.add_argument("--learning_rate", type=float, default=0.00001)
parser.add_argument("--num_epochs", type=int, default=10)

parser.add_argument("--aux_task", action='store_true', default=True)
parser.add_argument("--no_aux_task", dest='aux_task', action='store_false')

parser.add_argument("--mobile", action='store_true', default=False)
parser.add_argument("--no_mobile", dest='mobile', action='store_false')

parser.add_argument("--cam_pos", type=str, default="bot")
parser.add_argument("--net_id", type=str, default="newtest0")

args = parser.parse_args()

IMAGE_SIZE  = args.image_size
BATCH_SIZE  = args.batch_size
NUM_CLASSES = args.num_classes
GPU_NUM     = args.gpu
FOLDER      = args.folder
L_RATE      = args.learning_rate
N_EPOCH     = args.num_epochs
AUX_TASK    = args.aux_task
MOBILE      = args.mobile
CAM_POS     = args.cam_pos
net_id      = args.net_id

print()
print(args)
print()

# System Info and Config
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
#0 = all messages are logged (default behavior)
#1 = INFO messages are not printed
#2 = INFO and WARNING messages are not printed
#3 = INFO, WARNING, and ERROR messages are not printed

#GPU id to use
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"]=GPU_NUM

print()
print("tf.__version__ is", tf.__version__)
print("tf.keras.__version__ is:", tf.keras.__version__)
print("Num GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))
print(tf.test.gpu_device_name())


#color for mask viz
colormap = np.asarray([[100,  0,  0], [ 0,  0, 100], [ 0, 100,  0], [100,  0, 100], [100, 100, 0]])

TRAIN_DIR   = f"./{FOLDER}/train/"
VAL_DIR     = f"./{FOLDER}/val/"
TEST_DIR    = f"./{FOLDER}/test/"

if AUX_TASK:
    aux = "res_aux_true"
    if MOBILE:
        aux = "mob_aux_true"
else:
    aux = "res_aux_false"
    if MOBILE:
        aux = "mob_aux_false"

print('output name:',str(IMAGE_SIZE)+'px_'+str(CAM_POS)+'_'+str(aux)+'_'+str(N_EPOCH)+'ep_'+str(net_id)+'.hdf5')
print()

# Function to draw a line on an image (cv2.line() drop-in replacement)
def drawline(img, p1, p2, color):
    w, h = img.shape[0:2]
    
    # Extract x and y coordinates from the input points
    x_values = np.array([p1[1], p2[1]])
    y_values = np.array([p1[0], p2[0]])

    # Use linear regression to get the points of the line
    regr = LinearRegression()
    regr.fit(x_values.reshape(-1, 1), y_values.reshape(-1, 1))

    x_line = np.arange(w).reshape(-1, 1)
    y_line = np.asarray(regr.predict(x_line), np.int16)

    # Draw the line
    for i in range(len(x_line)):
        if y_line[i][0] + 2 > h - 2:
            break
        if y_line[i][0] + 2 > 0:
            img[x_line[i][0]][y_line[i][0]] = np.asarray(color)
            img[x_line[i][0]][y_line[i][0] + 1] = np.asarray(color)
            img[x_line[i][0]][y_line[i][0] - 1] = np.asarray(color)
            img[x_line[i][0]][y_line[i][0] + 2] = np.asarray([0,0,0])
            img[x_line[i][0]][y_line[i][0] - 2] = np.asarray([0,0,0])

    return img

# Function to blend two images (cv2.addWeighted() drop-in replacement)
def addimages(img1, alpha, img2, beta):
    
    result = np.asarray(img1 * alpha + img2 * beta, dtype=np.uint8)

    return np.clip(result,0,255)

# Function to decode the categorical segmentation masks to RGB colors
def decode_segmentation_masks(mask, colormap, n_classes):
    shape = (IMAGE_SIZE,IMAGE_SIZE)
    r = np.empty(shape,dtype=np.uint8)
    g = np.empty(shape,dtype=np.uint8)
    b = np.empty(shape,dtype=np.uint8)
        
    for l in range(0, n_classes):
        idx = mask == l
        r[idx] = colormap[l, 0]
        g[idx] = colormap[l, 1]
        b[idx] = colormap[l, 2]
        
    rgb = np.stack([r, g, b], axis=2)
    return rgb

# Function to randomly change image brightness and contrast for augmentation
def random_bright_contr(image, mask):
    """
    Randomly changes image brightness and contrast.

    Args:
        image (tf.Tensor): The input image tensor.
        mask (tf.Tensor): The associated mask tensor (not modified).

    Returns:
        tf.Tensor: The modified image tensor with random brightness and contrast.
        tf.Tensor: The unmodified mask tensor.
    """

    uniform_random = tf.random.uniform([], 0, 1.0)

    # Apply random brightness adjustment to the image with a maximum delta of 0.4
    # If uniform_random is less than 0.5, apply the adjustment; otherwise, keep the image unchanged
    image = tf.cond(tf.less(uniform_random, 0.5), lambda: tf.image.random_brightness(image, max_delta=0.4), lambda: image)

    # Generate another uniform random value between 0 and 1
    uniform_random = tf.random.uniform([], 0, 1.0)

    # Apply random contrast adjustment to the image with specified lower and upper bounds (0.75 and 1.4)
    # If uniform_random is less than 0.5, apply the adjustment; otherwise, keep the image unchanged
    image = tf.cond(tf.less(uniform_random, 0.5), lambda: tf.image.random_contrast(image, lower=0.75, upper=1.4), lambda: image)

    # Clip the pixel values of the image to be within the range [-1.0, 1.0]
    image = tf.clip_by_value(image, -1.0, 1.0)

    return image, mask

# Function to randomly flip the image for augmentation
def random_flip_image(image, mask, x0, x1):
    """
    Randomly flip an image and label horizontally.

    Args:
        image (tf.Tensor): The input image tensor.
        mask (tf.Tensor): The associated mask tensor.
        x0 (tf.Tensor): A value representing x0 coordinate (used for bounding boxes).
        x1 (tf.Tensor): A value representing x1 coordinate (used for bounding boxes).

    Returns:
        tf.Tensor: The modified image tensor (flipped or unchanged).
        tf.Tensor: The modified mask tensor (flipped or unchanged).
        tf.Tensor: The modified x0 coordinate (flipped or adjusted).
        tf.Tensor: The modified x1 coordinate (flipped or adjusted).
    """

    uniform_random = tf.random.uniform([], 0, 1.0)

    # Determine if a horizontal flip should be applied (50% probability)
    flipH_cond = tf.less(uniform_random, 0.5)

    image = tf.cond(flipH_cond, lambda: tf.image.flip_left_right(image), lambda: image)
    mask = tf.cond(flipH_cond, lambda: tf.image.flip_left_right(mask), lambda: mask)

    # Adjust X0/X1 if a horizontal flip was applied
    if flipH_cond:
        x0 = (0.5 - x0) + 0.5
        x1 = (0.5 - x1) + 0.5

    return image, mask, x0, x1

# Function read the image and X0/X1 from path
def read_image(image_path, mask=False):
    image = tf.io.read_file(image_path)
    if mask:
        image = tf.image.decode_png(image, channels=1)
        image.set_shape([None, None, 1])
        image = tf.image.resize(images=image, size=[IMAGE_SIZE, IMAGE_SIZE], method='nearest')
    else:
        image = tf.image.decode_png(image, channels=3)
        image.set_shape([None, None, 3])
        image = tf.image.resize(images=image, size=[IMAGE_SIZE, IMAGE_SIZE])
        image = image / 127.5 - 1
    return image

def read_X0(line_path):
    flabel = open(line_path, 'r')

    for lines in flabel.readlines():
        label = lines.rstrip().split(',') #mudado para espaço por causa do morango
        if len(label)<2:
            label = lines.rstrip().split(' ')

    x0 = eval(label[0])
    
    x0 = 1 / (1 + np.exp(-(x0 - 320) / 230))

    return x0

def read_X1(line_path):
    flabel = open(line_path, 'r')

    for lines in flabel.readlines():
        label = lines.rstrip().split(',') #mudado para espaço por causa do morango
        if len(label)<2:
            label = lines.rstrip().split(' ')
    
    x1 = eval(label[1])
    
    flabel.close()

    #if x1 < 0:
    #    x1 = (x1+640)/6400
    #elif x1 > 640:
    #    x1 = (x1-640)/6400 + 0.9
    #else:
    #    x1 = (x1)/800 + 0.1
    x1 = 1 / (1 + np.exp(-(x1 - 320) / 230))

    return x1

# Data generator loader
def load_data(image_list, mask_list, x0_list, x1_list):
    image = read_image(image_list)
    mask  = read_image(mask_list, mask=True)

    x0 = x0_list
    x1 = x1_list

    image,mask = random_bright_contr(image, mask)
    image,mask,x0,x1 = random_flip_image(image, mask, x0, x1)
    
    return image, (mask, x0, x1)

def data_generator(image_list, mask_list, line_list):
    X0_list = [read_X0(line) for line in line_list]
    X1_list = [read_X1(line) for line in line_list]
    print("loaded - img:",len(image_list)," - msk",len(mask_list)," - X0:",len(X0_list)," - X1",len(X1_list))

    dataset = tf.data.Dataset.from_tensor_slices((image_list, mask_list, X0_list, X1_list))
    dataset = dataset.map(load_data, num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.shuffle(buffer_size = 100 * BATCH_SIZE) 
    dataset = dataset.batch(BATCH_SIZE, drop_remainder=True)
    
    return dataset

def load_data_no_mask(image_list,  x0_list, x1_list):
    image = read_image(image_list)

    x0 = x0_list
    x1 = x1_list

    image,_ = random_bright_contr(image,image)
    image,_,x0,x1 = random_flip_image(image,image, x0, x1)
    
    return image, (x0, x1)

def data_generator_no_mask(image_list, line_list):
    X0_list = [read_X0(line) for line in line_list]
    X1_list  = [read_X1(line) for line in line_list]

    dataset = tf.data.Dataset.from_tensor_slices((image_list, X0_list, X1_list))
    dataset = dataset.map(load_data_no_mask, num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.shuffle(buffer_size = 100 * BATCH_SIZE) 
    dataset = dataset.batch(BATCH_SIZE, drop_remainder=True)
    
    return dataset

# Functions to get the file list from the folder
def loadpath_img(my_path):
    files = []
    for path in Path(my_path).rglob('*.jpg'):
        files.append(str(path))
    #if len(files) < 1:
    for path in Path(my_path).rglob('*img.png'):
        files.append(str(path))
    #print('PNG images detected, for better reliability use jpg for the images')
    files.sort()
    return files

def loadpath_msk(my_path):
    files = []
    for path in Path(my_path).rglob('*_cat.png'):
        files.append(str(path))
    files.sort()
    return files

def loadpath_lbl(my_path):
    files = []
    for path in Path(my_path).rglob('*_lbl.txt'):
        files.append(str(path))
    files.sort()
    return files

# Network Model blocks
# Network Model blocks
def convolution_block(
    block_input,
    num_filters=256,
    kernel_size=3,
    dilation_rate=1,
    padding="same",
    use_bias=False,
):
    x = layers.Conv2D(
        num_filters,
        kernel_size=kernel_size,
        dilation_rate=dilation_rate,
        padding="same",
        use_bias=use_bias,
        kernel_initializer=keras.initializers.HeNormal(),
    )(block_input)
    x = layers.BatchNormalization()(x)
    return tf.nn.relu(x)

def DilatedSpatialPyramidPooling(dspp_input):
    dims = dspp_input.shape
    x = layers.AveragePooling2D(pool_size=(dims[-3], dims[-2]))(dspp_input)
    x = convolution_block(x, kernel_size=1, use_bias=True)
    out_pool = layers.UpSampling2D(
        size=(dims[-3] // x.shape[1], dims[-2] // x.shape[2]), interpolation="bilinear",
    )(x)

    out_1 = convolution_block(dspp_input, kernel_size=1, dilation_rate=1)
    out_6 = convolution_block(dspp_input, kernel_size=3, dilation_rate=6)
    out_12 = convolution_block(dspp_input, kernel_size=3, dilation_rate=12)
    out_18 = convolution_block(dspp_input, kernel_size=3, dilation_rate=18)

    x = layers.Concatenate(axis=-1)([out_pool, out_1, out_6, out_12, out_18])
    output = convolution_block(x, kernel_size=1)
    return output

def get_x0(x):
    shape = x.shape

    flatten = layers.Flatten(input_shape=shape)(x)
    hidden_layer = layers.Dense(25, activation='relu', use_bias=True)(flatten)
    hidden_layer = layers.Dense(20, activation='relu', use_bias=True)(hidden_layer)
    output_x0 = layers.Dense(1, activation='sigmoid', use_bias=True, name="x0")(hidden_layer)

    return output_x0

def get_x1(x):
    shape = x.shape

    flatten = layers.Flatten(input_shape=shape)(x)
    hidden_layer = layers.Dense(25, activation='relu', use_bias=True)(flatten)
    hidden_layer = layers.Dense(20, activation='relu', use_bias=True)(hidden_layer)
    output_x1 = layers.Dense(1, activation='sigmoid', use_bias=True, name="x1")(hidden_layer)

    return output_x1

# Resnet with aux task (DeeplabV3+)
def DeeplabV3Plus(image_size, num_classes):
    model_input = keras.Input(shape=(image_size, image_size, 3))
    resnet50 = keras.applications.ResNet50(
        weights="imagenet", include_top=False, input_tensor=model_input
    )
    x = resnet50.get_layer("conv4_block6_2_relu").output
    
    x1_out = get_x1(x)
    x0_out = get_x0(x)

    x = DilatedSpatialPyramidPooling(x)

    input_a = layers.UpSampling2D(
        size=(image_size // 4 // x.shape[1], image_size // 4 // x.shape[2]),
        interpolation="bilinear",
    )(x)
    input_b = resnet50.get_layer("conv2_block3_2_relu").output
    input_b = convolution_block(input_b, num_filters=48, kernel_size=1)

    x = layers.Concatenate(axis=-1)([input_a, input_b])
    x = convolution_block(x)
    x = convolution_block(x)

    x = layers.UpSampling2D(
        size=(image_size // x.shape[1], image_size // x.shape[2]),
        interpolation="bilinear",
    )(x)

    model_output = layers.Conv2D(num_classes, kernel_size=(1, 1), padding="same", name="mask")(x)

    return keras.Model(inputs=model_input, outputs=[model_output, x0_out, x1_out])

# MobileNet with aux task (DeeplabV3+) (Check if running old version - BRACIS or Thesis)
def DeeplabV3_mobile2(image_size, num_classes):
    model_input = keras.Input(shape=(image_size, image_size, 3))
    MobileNet2 = keras.applications.MobileNetV2(
        weights="imagenet", include_top=False, input_tensor=model_input
    )
    x = MobileNet2.get_layer("block_16_project_BN").output
    #x = MobileNet2.get_layer("block_13_depthwise_relu").output #(Thesis and BRACIS compatibility)

    x1_out = get_x1(x)
    x0_out = get_x0(x)

    x = DilatedSpatialPyramidPooling(x)

    input_a = layers.UpSampling2D(
        size=(image_size // 4 // x.shape[1], image_size // 4 // x.shape[2]),
        interpolation="bilinear",
    )(x)
    input_b = MobileNet2.get_layer("block_2_add").output 
    input_b = convolution_block(input_b, num_filters=48, kernel_size=1)

    # Determine the desired spatial dimensions
    desired_height = input_b.shape[1]
    desired_width = input_b.shape[2]

    # Calculate the padding to add to input_b
    pad_height = desired_height - input_a.shape[1]
    pad_width = desired_width - input_a.shape[2]

    # Ensure the padding values are non-negative
    pad_height = max(0, pad_height)
    pad_width = max(0, pad_width)

    # Define the padding tensor
    padding = tf.constant([[0, 0], [pad_height // 2, pad_height // 2], [pad_width // 2, pad_width // 2], [0, 0]])

    # Pad input_b
    input_a = tf.pad(input_a, padding, "CONSTANT", constant_values=0)

    # Now, input_b has the same spatial dimensions as input_a
    # You can proceed to concatenate them
    x = layers.Concatenate(axis=-1)([input_a, input_b])

    x = convolution_block(x)
    x = convolution_block(x)

    x = layers.UpSampling2D(
        size=(image_size // x.shape[1], image_size // x.shape[2]),
        interpolation="bilinear",
    )(x)

    model_output = layers.Conv2D(num_classes, kernel_size=(1, 1), padding="same", name="mask")(x)
    return keras.Model(inputs=model_input, outputs=[model_output, x0_out, x1_out])

# Resnet without aux task
def resnet_model_no_aux(image_size, num_classes):
    model_input = keras.Input(shape=(image_size, image_size, 3))
    resnet50 = keras.applications.ResNet50(
        weights="imagenet", include_top=False, input_tensor=model_input
    )
    x = resnet50.get_layer("conv4_block6_2_relu").output
    
    x1_out = get_x1(x)
    x0_out = get_x0(x)

    return keras.Model(inputs=model_input, outputs=[ x0_out, x1_out])

# MobileNet without aux task
def mobile_model_no_aux(image_size, num_classes):
    model_input = keras.Input(shape=(image_size, image_size, 3))
    MobileNet2 = keras.applications.MobileNetV2(
        weights="imagenet", include_top=False, input_tensor=model_input
    )
    x = MobileNet2.get_layer("block_16_project_BN").output #block_13_depthwise_relu

    x1_out = get_x1(x)
    x0_out = get_x0(x)

    return keras.Model(inputs=model_input, outputs=[ x0_out, x1_out])

# Custom loss for multiple outputs
class deeplab_custom_loss(tf.losses.Loss):

    def __init__(self):
        super().__init__()
        self._deeplab_loss = keras.losses.SparseCategoricalCrossentropy(from_logits=True)
        self._MLP_x0_loss =  keras.losses.MeanAbsoluteError()
        self._MLP_x1_loss =  keras.losses.MeanAbsoluteError()

    def call(self, y_true, y_pred):

        mask_true = y_true[0]
        mask_pred = y_pred[0]

        x0_true = y_true[1]
        x0_pred = y_pred[1]

        x1_true = y_true[2]
        x1_pred = y_pred[2]
        
        deeplab_loss = self._deeplab_loss(mask_true , mask_pred)
        x0_loss = self._MLP_x0_loss(x0_true, x0_pred)
        x1_loss = self._MLP_x1_loss(x1_true, x1_pred)

        loss = (deeplab_loss + x0_loss*2 + x1_loss*2)/5
        return loss

class custom_loss_no_aux(tf.losses.Loss):
    """Wrapper to combine both the losses"""

    def __init__(self):
        super().__init__()
        self._MLP_x0_loss =  keras.losses.MeanAbsoluteError()
        self._MLP_x1_loss =  keras.losses.MeanAbsoluteError()

    def call(self, y_true, y_pred):

        x0_true = y_true[0]
        x0_pred = y_pred[0]

        x1_true = y_true[1]
        x1_pred = y_pred[1]
        
        x0_loss = self._MLP_x0_loss(x0_true, x0_pred)
        x1_loss = self._MLP_x1_loss(x1_true, x1_pred)

        loss = (x0_loss + x1_loss)/2
        return loss

def mean_iou(y_true, y_pred):
    # Convert one-hot encoded masks to class index masks
    y_true = tf.argmax(y_true, axis=-1)
    y_pred = tf.argmax(y_pred, axis=-1)

    # Calculate IOU for each class separately
    ious = []
    for class_index in range(NUM_CLASSES):  # Replace NUM_CLASSES with the number of classes
        true_class = tf.cast(tf.equal(y_true, class_index), tf.float32)
        pred_class = tf.cast(tf.equal(y_pred, class_index), tf.float32)

        intersection = tf.reduce_sum(true_class * pred_class)
        union = tf.reduce_sum(true_class) + tf.reduce_sum(pred_class) - intersection

        iou = (intersection + 1e-10) / (union + 1e-10)
        ious.append(iou)

    # Calculate Mean IOU across all classes
    mean_iou = tf.reduce_mean(ious)
    
    return mean_iou

def calculate_iou(mask1, mask2):
    # Calculate the area of intersection between two 2D masks
    intersection_area = np.sum(np.minimum(mask1, mask2))

    # Calculate the area of each mask
    area1 = np.sum(mask1)
    area2 = np.sum(mask2)

    # Calculate IoU
    union_area = area1 + area2 - intersection_area
    iou = intersection_area / union_area if union_area != 0 else 0

    return iou

# Functions for vizualization
def infer(model, image_tensor):
    mask,delta,theta = model.predict(np.expand_dims((image_tensor), axis=0), verbose = 0)
    predictions = np.squeeze(mask)
    return predictions, np.squeeze(delta), np.squeeze(theta)

def infer_no_aux(model, image_tensor):
    delta,theta = model.predict(np.expand_dims((image_tensor), axis=0), verbose = 0)
    return np.squeeze(delta), np.squeeze(theta)

def decode_segmentation_masks(mask, colormap, n_classes):
    r = np.zeros_like(mask).astype(np.uint8)
    g = np.zeros_like(mask).astype(np.uint8)
    b = np.zeros_like(mask).astype(np.uint8)
    for l in range(0, n_classes):
        idx = mask == l
        r[idx] = colormap[l, 0]
        g[idx] = colormap[l, 1]
        b[idx] = colormap[l, 2]
    rgb = np.stack([r, g, b], axis=2)
    return rgb

def get_overlay(image, colored_mask):
    image = tf.keras.preprocessing.image.array_to_img(image)
    colored_mask = tf.keras.preprocessing.image.array_to_img(colored_mask)
    
    image = np.array(image).astype(np.uint8)
    colored_mask = np.array(colored_mask).astype(np.uint8)

    overlay = addimages(image, 0.5, colored_mask, 0.5)
    return overlay

def plot_samples_matplotlib(display_list, figsize=(5, 3)):
    _, axes = plt.subplots(nrows=1, ncols=len(display_list), figsize=figsize)
    for i in range(len(display_list)):
        if display_list[i].shape[-1] == 3:
            axes[i].imshow(tf.keras.preprocessing.image.array_to_img(display_list[i]))
        else:
            axes[i].imshow(display_list[i])
    plt.show()

def plot_predictions(images_list, colormap, model, aux_task):
    proc_time = []; iou = []; x0_error = []; x1_error = []; avg_error = []
    i = 0
    
    for image_file in images_list:

        image_tensor = read_image(image_file)
        x0_true      = read_X0(image_file.replace('img.jpg','lbl.txt'))
        x1_true      = read_X1(image_file.replace('img.jpg','lbl.txt'))

        start_time = time.time()*1000

        if aux_task:
            mask_true    = read_image(image_file.replace('img.jpg','mask.png'))
            prediction_mixed, x0_pred, x1_pred = infer(image_tensor = image_tensor, model=model)
            prediction_colormap = decode_segmentation_masks(np.argmax(prediction_mixed, axis=2), colormap, NUM_CLASSES)
            overlay_pred = get_overlay(image_tensor, prediction_colormap)
            overlay_true = get_overlay(image_tensor, mask_true)

            mask_true_np = tf.keras.preprocessing.image.array_to_img(mask_true)
            mask_pred_np = tf.keras.preprocessing.image.array_to_img(prediction_colormap)
            iou.append(calculate_iou(mask_true_np, mask_pred_np))

        else:
            x0_pred, x1_pred = infer_no_aux(image_tensor = image_tensor, model=model)
            overlay_pred = tf.keras.preprocessing.image.array_to_img(image_tensor)
            overlay_pred = np.array(overlay_pred).astype(np.uint8)
            overlay_true = overlay_pred.copy()
            iou = [0]
            
        x0_true = int(np.round(-IMAGE_SIZE*0.359375*np.log((1 - x0_true) / x0_true) + IMAGE_SIZE/2))
        x1_true = int(np.round(-IMAGE_SIZE*0.359375*np.log((1 - x1_true) / x1_true) + IMAGE_SIZE/2))
        x0_pred = int(np.round(-IMAGE_SIZE*0.359375*np.log((1 - x0_pred) / x0_pred) + IMAGE_SIZE/2))
        x1_pred = int(np.round(-IMAGE_SIZE*0.359375*np.log((1 - x1_pred) / x1_pred) + IMAGE_SIZE/2))
            
        #if x0_true < 0.1:
        #    x0_true = round((x0_true*IMAGE_SIZE*10)-IMAGE_SIZE)
        #elif x0_true > 0.9:
        #    x0_true = round(((x0_true-0.9)*IMAGE_SIZE*10)+IMAGE_SIZE)
        #else:
        #    x0_true = round(((x0_true-0.1))*IMAGE_SIZE*1.25)

        x0_error.append(abs(x0_true-x0_pred))
        x1_error.append(abs(x1_true-x1_pred))
        avg_error.append((x0_error[-1]+x1_error[-1])/2)

        x0_error.append(abs(x0_true-x0_pred))
        x1_error.append(abs(x1_true-x1_pred))
        avg_error.append((x0_error[-1]+x1_error[-1])/2)

        end_time = time.time()*1000

        proc_time.append(int(end_time - start_time))

        overlay_pred = drawline(overlay_pred, (x0_true, 0), (x1_true, IMAGE_SIZE), (255, 255, 255))
        overlay_pred = drawline(overlay_pred, (x0_pred, 0), (x1_pred, IMAGE_SIZE), (255, 255, 0))    
        overlay_true = drawline(overlay_true, (x0_true, 0), (x1_true, IMAGE_SIZE), (255, 255, 255))

        if i%20 == 0:
            print(f"{i+1:03d} - P: ({x0_pred:03.0f}, {x1_pred:03.0f}) Gt: ({x0_true:03.0f}, {x1_true:03.0f}) - Time: {proc_time[-1]:03d} ms - IoU: {iou[-1]:.3f} - Er:({x0_error[-1]:03.0f}, {x1_error[-1]:03.0f}) - AVG: {avg_error[-1]:03.0f}")
            plot_samples_matplotlib([image_tensor, overlay_pred, overlay_true], figsize=(16, 4))
        i += 1

    print('Average Proc time.: ', np.average(proc_time))
    print('Average IoU.......: ', np.average(iou))
    print('Average X0 error..: ', np.average(x0_error))
    print('Average X1 error..: ', np.average(x1_error))
    print('Average Error.....: ', np.average(avg_error))
    print('Images Tested.....: ', len(proc_time))

    return [np.average(proc_time),np.average(iou),np.average(x0_error),np.average(x1_error),np.average(avg_error),len(proc_time)]

def average_and_format(data, label):
    avg = np.average(data)
    return f'Average {label}: {avg:.2f}'


# Dataset generation and size checks
train_images = loadpath_img(TRAIN_DIR)
if AUX_TASK: train_masks  = loadpath_msk(TRAIN_DIR)
train_txts   = loadpath_lbl(TRAIN_DIR)

val_images = loadpath_img(VAL_DIR)
if AUX_TASK: val_masks  = loadpath_msk(VAL_DIR)
val_txts   = loadpath_lbl(VAL_DIR)

test_images = loadpath_img(TEST_DIR)

print()
print("Train Dataset:")
if AUX_TASK: 
    train_dataset = data_generator(train_images, train_masks, train_txts)
else:
    train_dataset = data_generator_no_mask(train_images, train_txts)
print(train_dataset, end="\n\n")

print("Val   Dataset:")
if AUX_TASK: 
    val_dataset = data_generator(val_images  , val_masks  , val_txts  )
else:
    val_dataset = data_generator_no_mask(val_images, val_txts)
print(val_dataset, end="\n\n")

#print("test  Dataset:", test_images)
#print(train_images[0:3],  len(train_images))
#print(train_masks[0:3], len(train_masks))
#print(train_txts[0:3],  len(train_txts))

# Line normalization check, data should be corrected or removed if outside the desired range [0,1]
clear_flag = True
for data in train_txts:
    if read_X0(data)>1 or read_X1(data)>1:
        clear_flag = False
        print(data,read_X0(data),read_X1(data))
    if read_X0(data)<0 or read_X1(data)<0:
        clear_flag = False
        print(data,read_X0(data),read_X1(data))
print()
if clear_flag:
    print("Data is within the desired range")
else:
    print("Data above is outside of the desired range, trainig might fail")
print()

# Callbacks for Trainig phase
early_stopping = EarlyStopping(monitor='val_x1_mae', patience=50, min_delta=0.0001, mode='min', restore_best_weights=True)

mcp_save = ModelCheckpoint('/data/ifcosta/train_final/'+str(IMAGE_SIZE)+'px_'+str(CAM_POS)+'_'+str(aux)+'_'+str(N_EPOCH)+'ep_'+str(net_id)+'_checkpt.hdf5',
                           save_best_only=True, monitor='val_x1_mae', mode='min')

terminate = TerminateOnNaN()

# Training preparation
if AUX_TASK:
    if MOBILE: 
        custom_loss = deeplab_custom_loss()
        model = DeeplabV3_mobile2(image_size=IMAGE_SIZE, num_classes=NUM_CLASSES)
        model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=L_RATE),
        loss=custom_loss,
        metrics={'mask': ['accuracy'], 
                    'x0': ['mae'],
                    'x1': ['mae']})
    else:
        custom_loss = deeplab_custom_loss()
        model = DeeplabV3Plus(image_size=IMAGE_SIZE, num_classes=NUM_CLASSES)
        model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=L_RATE),
        loss=custom_loss,
        metrics={'mask': ['accuracy'], 
                'x0': ['mae'],
                'x1': ['mae']})
else:
    if MOBILE:
        custom_loss = custom_loss_no_aux()
        model = mobile_model_no_aux(image_size=IMAGE_SIZE, num_classes=NUM_CLASSES)
        model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=L_RATE),
        loss=custom_loss,
        metrics={'x0': ['mae'],
                'x1': ['mae']})
    else:
        custom_loss = custom_loss_no_aux()
        model = resnet_model_no_aux(image_size=IMAGE_SIZE, num_classes=NUM_CLASSES)
        model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=L_RATE),
        loss=custom_loss,
        metrics={'x0': ['mae'],
                'x1': ['mae']})

print(str(aux)+' model created')

#Load Pre trained weights
#model.load_weights('/data/ifcosta/train_final/'+str(IMAGE_SIZE)+'px_'+str(CAM_POS)+'_'+str(aux)+'_300ep_soymix9.hdf5')

#Training phase
start_time = time.time()
history = model.fit(train_dataset, validation_data=val_dataset, epochs=N_EPOCH, callbacks=[terminate, mcp_save])
end_time = time.time()

# Training Stats Plots
plt.figure(figsize=(20,8))
plt.subplots_adjust(wspace=0.13, hspace=0.25)
plt.rcParams.update({'font.size': 7})

plt.subplot(2, 3, 1)
plt.plot(history.history['x0_loss'],'-p', markersize=2, linewidth=1)
plt.plot(history.history['val_x0_loss'],'-p', markersize=2, linewidth=1)
plt.title('X0 loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train','val'], loc='upper right')
plt.ylim([0, 0.26])
plt.yticks(np.arange(0, 0.26, 0.05))

plt.subplot(2, 3, 4)
plt.plot(history.history['x0_mae'],'-p', markersize=2, linewidth=1)
plt.plot(history.history['val_x0_mae'],'-p', markersize=2, linewidth=1)
plt.title('X0 MAE')
plt.ylabel('Mean Average Error')
plt.xlabel('epoch')
plt.legend(['train','val'], loc='upper right')
plt.ylim([0, 0.10])
plt.yticks(np.arange(0, 0.11, 0.02))

plt.subplot(2, 3, 2)
plt.plot(history.history['x1_loss'],'-p', markersize=2, linewidth=1)
plt.plot(history.history['val_x1_loss'],'-p', markersize=2, linewidth=1)
plt.title('X1 loss')
plt.xlabel('epoch')
plt.legend(['train','val'], loc='upper right')
plt.ylim([0, 0.26])
plt.yticks(np.arange(0, 0.26, 0.05))

plt.subplot(2, 3, 5)
plt.plot(history.history['x1_mae'],'-p', markersize=2, linewidth=1)
plt.plot(history.history['val_x1_mae'],'-p', markersize=2, linewidth=1)
plt.title('X1 MAE')
plt.xlabel('epoch')
plt.legend(['train','val'], loc='upper right')
plt.ylim([0, 0.10])
plt.yticks(np.arange(0, 0.11, 0.02))

if AUX_TASK:
    plt.subplot(2, 3, 3)
    plt.plot(history.history['mask_loss'],'-p', markersize=2, linewidth=1)
    plt.plot(history.history['val_mask_loss'],'-p', markersize=2, linewidth=1)
    plt.title('mask loss')
    plt.xlabel('epoch')
    plt.legend(['train','val'], loc='upper right')
    plt.ylim([0, 2])
    plt.yticks(np.arange(0, 2, 0.1))

    plt.subplot(2, 3, 6)
    plt.plot(history.history['mask_accuracy'],'-p', markersize=2, linewidth=1)
    plt.plot(history.history['val_mask_accuracy'],'-p', markersize=2, linewidth=1)
    plt.title('mask accuracy')
    plt.xlabel('epoch')
    plt.ylabel('Accuracy')
    plt.legend(['train','val'], loc='upper right')
    plt.ylim([0, 1])
    plt.yticks(np.arange(0, 1, 0.1))

plt.savefig('/data/ifcosta/train_final/'+str(IMAGE_SIZE)+'px_'+str(CAM_POS)+'_'+str(aux)+'_'+str(N_EPOCH)+'ep_'+str(net_id)+'.png')
plt.close()

# Save history from training and Final Weights
# convert the history.history dict to a pandas DataFrame:     
hist_df = pd.DataFrame(history.history) 

#save to csv: 
hist_csv_file = '/data/ifcosta/train_final/'+str(IMAGE_SIZE)+'px_'+str(CAM_POS)+'_'+str(aux)+'_'+str(N_EPOCH)+'ep_'+str(net_id)+'.csv'
with open(hist_csv_file, mode='w') as f:
    hist_df.to_csv(f)

model.save_weights('/data/ifcosta/train_final/'+str(IMAGE_SIZE)+'px_'+str(CAM_POS)+'_'+str(aux)+'_'+str(N_EPOCH)+'ep_'+str(net_id)+'.hdf5')

output_layers = [model.get_layer("x0").output ,model.get_layer("x1").output]
evaluate_model = Model(inputs=model.input, outputs=output_layers)


_ = plot_predictions(test_images[0:10], colormap, model=evaluate_model, aux_task = False)
if AUX_TASK:
    _ = plot_predictions(test_images[0:10], colormap, model=model, aux_task = True)

out1 = plot_predictions(test_images, colormap, model=evaluate_model, aux_task = False)
if AUX_TASK:
    out0 = plot_predictions(test_images, colormap, model=model, aux_task = True)
else:
    out0 = out1

total_time = end_time - start_time

output = []
output.append('Default config with aux task:')
output.append(average_and_format(out0[0], "Proc time"))
output.append(average_and_format(out0[1], "IoU"))
output.append(average_and_format(out0[2], "X0 error"))
output.append(average_and_format(out0[3], "X1 error"))
output.append(average_and_format(out0[4], "Error"))
output.append(f'Images Tested: {out0[5]}')
output.append('')
output.append('Default config:')
output.append(average_and_format(out1[0], "Proc time"))
output.append(average_and_format(out1[1], "IoU"))
output.append(average_and_format(out1[2], "X0 error"))
output.append(average_and_format(out1[3], "X1 error"))
output.append(average_and_format(out1[4], "Error"))
output.append(f'Images Tested: {out1[5]}')
output.append('')
output.append(f'Total Training Time: {total_time:.2f} seconds')

result_file = '/data/ifcosta/train_final/'+str(IMAGE_SIZE)+'px_'+str(CAM_POS)+'_'+str(aux)+'_'+str(N_EPOCH)+'ep_'+str(net_id)+'.txt'

with open(result_file, 'w') as file:
    for line in output:
        file.write(line + '\n')